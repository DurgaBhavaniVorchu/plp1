import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { BankingComponent } from './Login/banking/banking.component';
import { CreateComponent } from './Banking/create/create.component';
import { DepositComponent } from './Banking/deposit/deposit.component';
import { WithdrawalComponent } from './Banking/withdrawal/withdrawal.component';
import { TransferComponent } from './Banking/transfer/transfer.component';
import { TransactionsComponent } from './Banking/transactions/transactions.component';
import { BalanceComponent } from './Banking/balance/balance.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { BankService } from './Service/bank.service';
import { LogoutComponent } from './Banking/logout/logout.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BankingComponent,
    CreateComponent,
    DepositComponent,
    WithdrawalComponent,
    TransferComponent,
    TransactionsComponent,
    BalanceComponent,
    LogoutComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,BankService],
  bootstrap: [AppComponent]
})
export class AppModule { }
