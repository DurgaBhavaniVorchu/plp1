export class Transactions
{
    transNo:number;
    accno:number;
    transTo:number;
    currentBal:number;
    transType:string;

    constructor(transNo:number,accno:number,transTo:number, currentBal:number,transType:string)
    {
        this.transNo=transNo;
        this.accno=accno;
        this.transTo=transTo;
        this.currentBal=currentBal;
        this.transType=transType;
    }
}