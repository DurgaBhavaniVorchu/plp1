import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BalanceComponent } from './Banking/balance/balance.component';
import { DepositComponent } from './Banking/deposit/deposit.component';
import { WithdrawalComponent } from './Banking/withdrawal/withdrawal.component';
import { TransferComponent } from './Banking/transfer/transfer.component';
import { HomeComponent } from './home/home.component';
import { TransactionsComponent } from './Banking/transactions/transactions.component';
import { CreateComponent } from './Banking/create/create.component';
import { BankingComponent } from './Login/banking/banking.component';
import { LogoutComponent } from './Banking/logout/logout.component';


const routes: Routes = [
  {
    path:'home',
    component : HomeComponent
  },
  {
    path:'create',
    component: CreateComponent
  },
  {
    path:'banking',
    component: BankingComponent
  },
  {
    path:'balance',
    component: BalanceComponent
  },
  {
    path:'home/balance',
    component: BalanceComponent
  },
  {
    path:'deposit',
    component : DepositComponent
  },
  {
    path:'home/deposit',
    component : DepositComponent
  },
  {
    path:'withdraw',
    component : WithdrawalComponent
  },
  {
    path:'home/withdraw',
    component : WithdrawalComponent
  }, 
  {
    path:'transfer',
    component : TransferComponent
  },
  {
    path:'home/transfer',
    component : TransferComponent
  },
  {
    path:'transactions',
    component : TransactionsComponent
  },
  {
    path:'home/transactions',
    component : TransactionsComponent
  },
  {
    path:'logout',
    component: LogoutComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
