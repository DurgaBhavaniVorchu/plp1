import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Transactions } from '../Entity/Transactions';
import { Account } from '../Entity/Account';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {
  http:HttpClient;
  isLogin:boolean=true;
  accounts:Account[]=[];
  transactions:Transactions[]=[];
  tempTrans:Transactions[]=[];
  fetched:boolean=false;
  fetched1:boolean=false;
  loginAccount:number=0;

  constructor(http:HttpClient) {
    this.http=http;
    this.fetchAccounts();
   // this.fetchTransactions();
   }

  fetchAccounts()
  {
    this.http.get('http://localhost:5052/BankApplication/getAllAccounts')
    .subscribe
    (
      data=>
      {
        // if(!this.fetched)
        // {
          console.log(data)
          this.convert(data);
          
          //this.fetched=true;
       // }
      }
    );
  }
  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Account(o.accNum,o.accName,o.accPh,o.accPass,o.accAdd,o.accBal);
      this.accounts.push(e);
    }
  }
  fetchTransactions()
  {
      this.http.get('./assets/Transactions.json')
      .subscribe
      (
        data=>
        {
          if(!this.fetched1)
          {
            this.convertTrans(data);
            this.fetched1=true;
          }
        }
      );
  }
  convertTrans(dataT:any)
  {
    for(let o of dataT)
    {
      let e=new Transactions(o.transId,o.transFrom,o.transTo,o.transAmount,o.transType);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }
  
  getAccounts():Account[]
  {
    return this.accounts;
  }

  // getTransactions():Transactions[]
  // {
  //   return this.transactions;
  // }

  showTransactions(accNum:number):Observable<any>{
    return this.http.get('http://localhost:5052/BankApplication/MiniStatement/'+accNum);
  }

  add(e:Account):Observable<any>{
    var obj=  {
      "pwd":e.pwd,
      "name":e.name,
      "address":e.address,
      "bal":e.bal,
      "mobNo":e.mobNo
  }

    return this.http.post('http://localhost:5052/BankApplication/CreateAccount',obj);

  }

  addTransaction(e:Transactions){
    this.transactions.push(e);
  }

  showBalance(data:any):Observable<any>{
    return this.http.get('http://localhost:5052/BankApplication/ShowBalance/'+data.accNum);

  }

  deposit(accNum:number,accBal:number):Observable<any>{
    return this.http.put('http://localhost:5052/BankApplication/DepositAmount/'+accNum+"/"+accBal,null);

  }
  
  withdraw(accNum:number,accBal:number):Observable<any>{
    return this.http.put('http://localhost:5052/BankApplication/WithdrawAmount/'+accNum+"/"+accBal,null);

  }
  transfer(accNum:number,accBal:number,accNum2:number):Observable<any>
  {
    return this.http.put('http://localhost:5052/BankApplication/FundTransfer/'+accNum+"/"+accBal+"/"+accNum2,null);
  }

  login(data:Account):boolean
  {
    let accNum=data.accNo;
    let accPass=data.pwd;

    for(let a of this.accounts)
    {
      console.log(this.accounts)
      if(accNum == a.accNo && accPass == a.pwd)
      {
       
        alert("Login Successful")
        this.isLogin=!this.isLogin;
        return true;
      }
      else
      {
        continue;
      }
      
    }
    return false;
  }
 
}
